/* دزد سایه‌ها — منطق بازی، رابط، رندر و صدا */
(function () {
  'use strict';
  var E = window.Engine, CH = window.CHAPTERS, CHARS = window.CHARS;
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var fa = function (n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); };
  var PLAYER_SPEED = 8;                 // خانه در ثانیه
  var KEY_COLORS = ['#ff5d5d', '#4dd2ff', '#7dff6b', '#ffa94d'];
  var PORTAL_COLORS = ['#b66dff', '#4dd2ff'];
  var ALL_PALS = [].concat.apply([], CH.map(function (c) { return c.zones.map(function (z) { return z.pal; }); }));

  var SKINS = [
    { id: 'classic', name: 'کلاسیک', price: 0, body: '#2b2b3d', accent: '#f5c542', eye: '#ffffff', trail: '#9b8cff' },
    { id: 'crimson', name: 'سرخ‌پوش', price: 40, body: '#7a1c2b', accent: '#ff6b81', eye: '#ffffff', trail: '#ff6b81' },
    { id: 'forest', name: 'شبح جنگل', price: 70, body: '#1f4d36', accent: '#7dff9b', eye: '#eaffea', trail: '#7dff9b' },
    { id: 'ghost', name: 'روح', price: 120, body: '#d9e2f2', accent: '#8aa4ff', eye: '#222233', trail: '#cfe0ff' },
    { id: 'gold', name: 'طلایی', price: 220, body: '#b8860b', accent: '#fff3b0', eye: '#2b1a00', trail: '#ffd84d' },
    { id: 'neon', name: 'نئون', price: 350, body: '#10002b', accent: '#00f5d4', eye: '#00f5d4', trail: '#f15bb5' }
  ];

  /* ---------- ذخیره ---------- */
  var KEY = 'shadowThief_v1';
  function defaults() { return { prog: [0, 0], stars: {}, bestCoins: {}, coins: 0, skins: ['classic'], skin: 'classic', seen: {}, daily: {}, endless: 1, sound: true, music: true, vib: true }; }
  var save = (function () { try { var s = JSON.parse(localStorage.getItem(KEY)); if (s) return Object.assign(defaults(), s); } catch (e) {} return defaults(); })();
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) {} }
  function skinOf() { return SKINS.filter(function (s) { return s.id === save.skin; })[0] || SKINS[0]; }

  /* ---------- صدا و لرزش ---------- */
  var Snd = {
    ac: null, mt: null,
    unlock: function () {
      if (!this.ac) { try { this.ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; } }
      if (this.ac.state === 'suspended') this.ac.resume();
      if (!this.mt) {
        var self = this, notes = [110, 131, 147, 165, 196, 220, 262];
        this.mt = setInterval(function () { if (save.music) self.tone(notes[(Math.random() * notes.length) | 0] / (Math.random() < .3 ? 2 : 1), 1.6, 'triangle', 0.03); }, 800);
      }
    },
    tone: function (f, d, type, v, slide) {
      if (!save.sound || !this.ac) return;
      var t = this.ac.currentTime, o = this.ac.createOscillator(), g = this.ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, f + slide), t + d);
      g.gain.setValueAtTime(v || 0.08, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(this.ac.destination); o.start(t); o.stop(t + d + 0.03);
    },
    step: function () { this.tone(140, 0.05, 'square', 0.012); },
    coin: function () { var s = this; s.tone(880, 0.09, 'sine', 0.09); setTimeout(function () { s.tone(1320, 0.14, 'sine', 0.09); }, 70); },
    key: function () { var s = this; [660, 880, 1100].forEach(function (f, i) { setTimeout(function () { s.tone(f, 0.12, 'triangle', 0.09); }, i * 70); }); },
    door: function () { this.tone(220, 0.3, 'sawtooth', 0.07, -120); },
    locked: function () { this.tone(110, 0.15, 'square', 0.06); },
    portal: function () { this.tone(300, 0.4, 'sine', 0.08, 900); },
    caught: function () { this.tone(300, 0.5, 'sawtooth', 0.1, -240); },
    win: function () { var s = this; [523, 659, 784, 1047].forEach(function (f, i) { setTimeout(function () { s.tone(f, 0.25, 'triangle', 0.1); }, i * 120); }); },
    tap: function () { this.tone(520, 0.05, 'sine', 0.05); }
  };
  function vib(p) { if (save.vib && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) {} } }

  /* ---------- رابط ---------- */
  var toastT = 0;
  function toast(t, ms) {
    var el = $('#toast'); el.textContent = t; el.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(function () { el.classList.remove('show'); }, ms || 2600);
  }
  var navStack = [];
  function show(id, noPush) {
    var cur = $('.screen.active');
    if (cur && !noPush && cur.id !== id) navStack.push(cur.id);
    $$('.screen').forEach(function (s) { s.classList.toggle('active', s.id === id); });
    refreshCoins();
  }
  function back() { show(navStack.pop() || 'menu', true); if ($('.screen.active').id === 'levels') renderLevels(); }
  function refreshCoins() { $('#m-coins').textContent = fa(save.coins); $$('.coin-live').forEach(function (e) { e.textContent = fa(save.coins); }); }
  $$('[data-back]').forEach(function (b) { b.onclick = function () { Snd.tap(); back(); }; });

  /* ---------- داستان ---------- */
  var storyTimer = 0;
  function playStory(lines, art, done) {
    var ov = $('#story'), i = 0, typing = false, full = '', pos = 0;
    $('#st-art').textContent = art || '🌙';
    ov.classList.add('show');
    function line() {
      if (i >= lines.length) return finish();
      var l = lines[i++], c = CHARS[l.w] || CHARS.narr;
      $('#st-emoji').textContent = c.emoji; $('#st-name').textContent = c.name;
      full = l.t; pos = 0; typing = true; $('#st-text').textContent = '';
      clearInterval(storyTimer);
      storyTimer = setInterval(function () {
        pos += 1; $('#st-text').textContent = full.slice(0, pos);
        if (pos >= full.length) { typing = false; clearInterval(storyTimer); }
      }, 28);
    }
    function finish() { clearInterval(storyTimer); ov.classList.remove('show'); ov.onclick = null; $('#st-skip').onclick = null; done && done(); }
    ov.onclick = function () {
      Snd.unlock();
      if (typing) { clearInterval(storyTimer); typing = false; $('#st-text').textContent = full; } else line();
    };
    $('#st-skip').onclick = function (e) { e.stopPropagation(); finish(); };
    line();
  }
  function playPacks(packs, done) {
    var i = 0;
    (function nx() {
      if (i >= packs.length) return done();
      var p = packs[i++];
      playStory(p.lines, p.art, function () { if (p.key) { save.seen[p.key] = 1; persist(); } nx(); });
    })();
  }

  /* ---------- انتخاب مرحله ---------- */
  var selCh = 0;
  function nextLevelRef() {
    for (var c = 0; c < CH.length; c++) if (save.prog[c] < CH[c].levels) return { ch: c, n: save.prog[c] + 1 };
    return { ch: CH.length - 1, n: CH[CH.length - 1].levels };
  }
  function chUnlocked(c) { return c === 0 || save.prog[c - 1] >= CH[c - 1].levels; }
  function renderLevels() {
    var tabs = $('#tabs'); tabs.innerHTML = '';
    CH.forEach(function (c, i) {
      var b = document.createElement('button');
      b.className = 'tab' + (i === selCh ? ' on' : '') + (chUnlocked(i) ? '' : ' lock');
      b.textContent = (chUnlocked(i) ? '' : '🔒 ') + 'فصل ' + fa(c.id) + ': ' + c.title;
      b.onclick = function () { if (!chUnlocked(i)) return toast('اول فصل قبل رو تموم کن!'); selCh = i; renderLevels(); };
      tabs.appendChild(b);
    });
    var soon = document.createElement('button'); soon.className = 'tab lock'; soon.textContent = '🔒 فصل ۳: به‌زودی'; soon.onclick = function () { toast('فصل سوم در راه است...'); }; tabs.appendChild(soon);
    var g = $('#lvgrid'); g.innerHTML = '';
    var ch = CH[selCh], cur = save.prog[selCh] + 1;
    ch.zones.forEach(function (z) {
      var h = document.createElement('div'); h.className = 'zone';
      h.innerHTML = '<span>' + z.emoji + '</span>' + z.name + ' <small>' + fa(z.from) + '–' + fa(z.to) + '</small>';
      g.appendChild(h);
      var grid = document.createElement('div'); grid.className = 'grid';
      for (var n = z.from; n <= z.to; n++) (function (n) {
        var b = document.createElement('button'), st = save.stars[selCh + '-' + n] || 0;
        b.className = 'lv' + (n % 20 === 0 ? ' boss' : '') + (n > cur ? ' locked' : '') + (n === cur ? ' cur' : '');
        b.innerHTML = (n % 20 === 0 ? '👑' : fa(n)) + '<small>' + (st ? '★'.repeat(st) : '') + '</small>';
        b.onclick = function () { Snd.unlock(); Snd.tap(); startStoryLevel(selCh, n); };
        grid.appendChild(b);
      })(n);
      g.appendChild(grid);
    });
    if (selCh === CH.length - 1) { var s = document.createElement('div'); s.className = 'soon'; s.textContent = '✨ فصل‌های بعدی به‌زودی اضافه می‌شوند'; g.appendChild(s); }
    var curEl = g.querySelector('.cur'); if (curEl) setTimeout(function () { curEl.scrollIntoView({ block: 'center' }); }, 30);
  }

  /* ---------- فروشگاه ---------- */
  function drawThief(c, x, y, r, s, bob) {
    c.save(); c.translate(x, y + (bob || 0));
    c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(0, r * 1.05 - (bob || 0), r * 0.8, r * 0.25, 0, 0, 6.3); c.fill();
    c.fillStyle = s.body; c.shadowColor = s.accent; c.shadowBlur = r * 0.5;
    c.beginPath(); c.arc(0, 0, r, 0, 6.3); c.fill(); c.shadowBlur = 0;
    c.fillStyle = '#0a0a12'; c.beginPath(); c.ellipse(0, -r * 0.1, r * 0.66, r * 0.42, 0, 0, 6.3); c.fill();
    c.fillStyle = s.eye; c.beginPath(); c.arc(-r * 0.26, -r * 0.12, r * 0.13, 0, 6.3); c.arc(r * 0.26, -r * 0.12, r * 0.13, 0, 6.3); c.fill();
    c.fillStyle = s.accent; c.beginPath(); c.ellipse(0, r * 0.58, r * 0.55, r * 0.17, 0, 0, 6.3); c.fill();
    c.restore();
  }
  function renderShop() {
    var box = $('#skins'); box.innerHTML = '';
    SKINS.forEach(function (s) {
      var d = document.createElement('div'), own = save.skins.indexOf(s.id) >= 0;
      d.className = 'skin' + (save.skin === s.id ? ' sel' : '');
      var cv = document.createElement('canvas'); cv.width = cv.height = 180;
      var c = cv.getContext('2d'); drawThief(c, 90, 90, 48, s, 0);
      var nm = document.createElement('div'); nm.textContent = s.name;
      var b = document.createElement('button'); b.className = 'btn';
      b.textContent = save.skin === s.id ? '✔ انتخاب‌شده' : own ? 'انتخاب' : '🪙 ' + fa(s.price);
      b.onclick = function () {
        Snd.tap();
        if (own) { save.skin = s.id; }
        else if (save.coins >= s.price) { save.coins -= s.price; save.skins.push(s.id); save.skin = s.id; Snd.coin(); }
        else return toast('سکه‌ی کافی نداری!');
        persist(); renderShop(); refreshCoins();
      };
      d.appendChild(cv); d.appendChild(nm); d.appendChild(b); box.appendChild(d);
    });
  }

  /* ---------- تنظیمات ---------- */
  function renderSettings() {
    $('#s-sound').textContent = save.sound ? '🔊 صدا: روشن' : '🔇 صدا: خاموش';
    $('#s-music').textContent = save.music ? '🎵 موسیقی: روشن' : '🎵 موسیقی: خاموش';
    $('#s-vib').textContent = save.vib ? '📳 لرزش: روشن' : '📳 لرزش: خاموش';
  }
  $('#s-sound').onclick = function () { save.sound = !save.sound; persist(); renderSettings(); };
  $('#s-music').onclick = function () { save.music = !save.music; persist(); renderSettings(); };
  $('#s-vib').onclick = function () { save.vib = !save.vib; persist(); renderSettings(); vib(40); };
  $('#s-reset').onclick = function () { if (confirm('همه‌ی پیشرفت پاک شود؟')) { save = defaults(); persist(); renderSettings(); refreshCoins(); toast('پاک شد'); } };

  /* ---------- وضعیت بازی ---------- */
  var cv = $('#cv'), cx = cv.getContext('2d'), stage = $('#stage');
  var cw = 0, chh = 0, dpr = 1;
  var G = { run: false, paused: false, done: false, L: null, meta: null, cs: 40, camX: 0, camY: 0, t: 0, time: 0, caught: 0, inv: 0, flash: 0, shake: 0, hintT: 0, hint: null, trail: [], trailT: 0, stat: null, pal: null };

  function fitCanvas() {
    var r = stage.getBoundingClientRect();
    dpr = Math.min(window.devicePixelRatio || 1, 2); cw = r.width; chh = r.height;
    cv.width = Math.round(cw * dpr); cv.height = Math.round(chh * dpr); cv.style.width = cw + 'px'; cv.style.height = chh + 'px';
  }
  function layout() {
    fitCanvas();
    if (!G.L) return;
    G.cs = Math.max(34, Math.min(60, Math.floor(cw / G.L.cols)));
    renderStatic();
  }
  window.addEventListener('resize', function () { if ($('#game').classList.contains('active')) layout(); });

  function renderStatic() {
    var L = G.L, cs = G.cs, pal = G.pal, o = document.createElement('canvas');
    o.width = Math.round(L.cols * cs * dpr); o.height = Math.round(L.rows * cs * dpr);
    var c = o.getContext('2d'); c.scale(dpr, dpr);
    c.fillStyle = pal.floor; c.fillRect(0, 0, L.cols * cs, L.rows * cs);
    for (var i = 0; i < L.m.length; i++) {
      var x = (i % L.cols) * cs, y = ((i / L.cols) | 0) * cs;
      if (((i % L.cols) + ((i / L.cols) | 0)) % 2) { c.fillStyle = 'rgba(255,255,255,.025)'; c.fillRect(x, y, cs, cs); }
    }
    c.strokeStyle = pal.wall; c.lineWidth = Math.max(3, cs * 0.09); c.lineCap = 'round';
    c.shadowColor = pal.wall; c.shadowBlur = cs * 0.3;
    c.beginPath();
    for (i = 0; i < L.m.length; i++) {
      var r = (i / L.cols) | 0, cc = i % L.cols, m = L.m[i]; x = cc * cs; y = r * cs;
      if (!(m & E.N) && !(r === 0 && cc === L.start)) { c.moveTo(x, y); c.lineTo(x + cs, y); }
      if (!(m & E.W)) { c.moveTo(x, y); c.lineTo(x, y + cs); }
      if (r === L.rows - 1 && !(m & E.S)) { c.moveTo(x, y + cs); c.lineTo(x + cs, y + cs); }
      if (cc === L.cols - 1 && !(m & E.E)) { c.moveTo(x + cs, y); c.lineTo(x + cs, y + cs); }
    }
    c.stroke();
    G.stat = o;
  }

  function cellXY(i) { return { x: (i % G.L.cols) + 0.5, y: ((i / G.L.cols) | 0) + 0.5 }; }

  function setupLevel(meta) {
    var L = E.buildLevel(meta.cfg);
    G.L = L; G.meta = meta; G.pal = meta.pal;
    G.doorAt = new Map(L.doors.map(function (d) { return [d.cell, d.color]; }));
    G.keyAt = new Map(L.keys.map(function (k) { return [k.cell, k.color]; }));
    G.portAt = new Map();
    L.portals.forEach(function (p, i) { G.portAt.set(p[0], { to: p[1], i: i }); G.portAt.set(p[1], { to: p[0], i: i }); });
    G.coinSet = new Set(L.coins); G.got = new Set(); G.held = new Set(); G.opened = new Set();
    G.trail = []; G.hint = null; G.hintT = 0; G.time = 0; G.t = 0; G.caught = 0; G.inv = 0.8; G.flash = 0; G.shake = 0; G.done = false; G.paused = false;
    G.p = { i: L.start, to: -1, t: 0, dir: 0, q: 0, qt: 0, pc: -1 };
    $('#h-lv').textContent = meta.label;
    show('game');
    layout();
    var pp = cellXY(L.start); G.camX = pp.x * G.cs - cw / 2; G.camY = pp.y * G.cs - chh / 2; clampCam(true);
    G.run = true;
    if (meta.tip) toast(meta.tip, 4200);
    hud();
  }

  /* ---------- حرکت ---------- */
  function canMove(i, d) {
    if (!(G.L.m[i] & d)) return false;
    var ni = i + E.DR[d] * G.L.cols + E.DC[d];
    var dc = G.doorAt.get(ni);
    if (dc !== undefined && !G.opened.has(ni) && !G.held.has(dc)) return false;
    return true;
  }
  function begin(d) { var p = G.p; p.dir = d; p.to = p.i + E.DR[d] * G.L.cols + E.DC[d]; p.t = 0; }
  function swipe(d) {
    if (!G.run || G.paused || G.done) return;
    var p = G.p;
    if (!p.dir) {
      if (canMove(p.i, d)) begin(d);
      else if (G.L.m[p.i] & d) { Snd.locked(); vib(25); toast('🔒 این در قفله — کلید هم‌رنگش رو پیدا کن', 1800); }
    } else if (d === E.OPP[p.dir]) {
      if (p.t > 0.001) { var tmp = p.i; p.i = p.to; p.to = tmp; p.t = 1 - p.t; p.dir = d; } else if (canMove(p.i, d)) begin(d);
    } else if (d !== p.dir) { p.q = d; p.qt = performance.now(); }
  }
  function decide() {
    var p = G.p, i = p.i, d = 0;
    if (p.q && performance.now() - p.qt < 450 && canMove(i, p.q)) { d = p.q; }
    else if (p.dir && canMove(i, p.dir)) d = p.dir;
    else if (p.dir) {
      var opts = E.DIRS.filter(function (x) { return x !== E.OPP[p.dir] && canMove(i, x); });
      if (opts.length === 1) d = opts[0];
    }
    p.q = 0;
    if (d) begin(d); else { p.dir = 0; p.to = -1; p.t = 0; }
  }
  function arrive() {
    var p = G.p, L = G.L; p.i = p.to; p.t = 0;
    var i = p.i;
    if (p.pc !== i) p.pc = -1;
    Snd.step();
    if (G.coinSet.has(i) && !G.got.has(i)) { G.got.add(i); Snd.coin(); vib(15); }
    if (G.keyAt.has(i) && !G.held.has(G.keyAt.get(i))) { G.held.add(G.keyAt.get(i)); G.keyAt.delete(i); Snd.key(); vib(30); toast('🔑 کلید برداشتی!', 1400); }
    if (G.doorAt.has(i) && !G.opened.has(i)) { G.opened.add(i); G.held.delete(G.doorAt.get(i)); Snd.door(); vib(40); }
    if (G.portAt.has(i) && p.pc !== i) {
      var dest = G.portAt.get(i).to; p.i = dest; p.pc = dest; Snd.portal(); vib([20, 30, 20]); G.flash = 0.6; G.trail = [];
    }
    if (p.i === L.exit) { p.dir = 0; p.to = -1; return win(); }
    decide();
  }
  function stepPlayer(dt) {
    var p = G.p, mv = PLAYER_SPEED * dt, guard = 0;
    while (mv > 0 && p.dir && guard++ < 20) {
      var rem = 1 - p.t;
      if (mv < rem) { p.t += mv; mv = 0; } else { mv -= rem; arrive(); if (G.done) return; }
    }
  }
  function playerPos() {
    var p = G.p, a = cellXY(p.i);
    if (!p.dir || p.to < 0) return a;
    var b = cellXY(p.to);
    return { x: a.x + (b.x - a.x) * p.t, y: a.y + (b.y - a.y) * p.t };
  }
  function guardPos(g, t) {
    var n = g.seg.length - 1, q = (g.phase + t * g.speed) % (2 * n);
    if (q > n) q = 2 * n - q;
    var a = Math.min(Math.floor(q), n - 1), f = q - a, A = cellXY(g.seg[a]), B = cellXY(g.seg[a + 1]);
    return { x: A.x + (B.x - A.x) * f, y: A.y + (B.y - A.y) * f };
  }

  /* ---------- رویدادها ---------- */
  function caught() {
    G.caught++; G.flash = 1; G.shake = 0.4; G.inv = 1.4; Snd.caught(); vib([90, 40, 90]);
    G.p = { i: G.L.start, to: -1, t: 0, dir: 0, q: 0, qt: 0, pc: -1 }; G.trail = [];
    toast('💂 گیر افتادی! برگشتی به شروع', 1800);
  }
  function drown() {
    G.done = true; Snd.caught(); vib(200); toast('💧 آب بالا اومد! دوباره تلاش کن', 1800);
    setTimeout(function () { restart(); }, 1100);
  }
  function win() {
    if (G.done) return; G.done = true; Snd.win(); vib([40, 40, 80]);
    var L = G.L, stars = 1, allCoins = G.got.size >= L.coins.length;
    if (allCoins) stars++;
    if (G.caught === 0 && G.time <= L.par) stars++;
    var m = G.meta, earned = G.got.size, bonus = 0, info = '';
    if (m.mode === 'story') {
      var k = m.ch + '-' + m.n, prev = save.bestCoins[k] || 0;
      earned = Math.max(0, G.got.size - prev); save.bestCoins[k] = Math.max(prev, G.got.size);
      save.stars[k] = Math.max(save.stars[k] || 0, stars);
      if (m.n > save.prog[m.ch]) save.prog[m.ch] = m.n;
    } else if (m.mode === 'daily') {
      var dd = save.daily[m.date] || {};
      if (!dd.done) bonus = 20;
      dd.done = true; dd.best = Math.min(dd.best || 1e9, Math.round(G.time)); save.daily[m.date] = dd;
    } else if (m.mode === 'endless') {
      save.endless = Math.max(save.endless, m.n + 1);
    }
    save.coins += earned + bonus; persist();
    info = '🪙 +' + fa(earned + bonus) + '   ⏱ ' + fa(Math.round(G.time)) + ' ثانیه' + (G.caught ? '   💂 ' + fa(G.caught) + ' بار گیر افتادی' : '');
    setTimeout(function () { showResult(stars, info); }, 600);
  }
  function showResult(stars, info) {
    var m = G.meta, st = $('#r-stars'); st.innerHTML = '';
    for (var i = 0; i < 3; i++) { var s = document.createElement('span'); s.textContent = '⭐'; st.appendChild(s); (function (s, on) { if (on) setTimeout(function () { s.classList.add('on'); Snd.tap(); }, 300 + i * 350); })(s, i < stars); }
    $('#r-title').textContent = m.boss ? '👑 مرحله‌ی ویژه تمام شد!' : 'مرحله تمام شد!';
    $('#r-info').textContent = info;
    var next = $('#r-next');
    if (m.mode === 'story') next.textContent = m.n >= CH[m.ch].levels ? '🎬 ادامه‌ی داستان' : 'مرحله‌ی بعد ▶';
    else if (m.mode === 'endless') next.textContent = 'مرحله‌ی بعد ▶';
    else next.textContent = 'منو';
    $('#result').classList.add('show');
  }
  $('#r-next').onclick = function () {
    $('#result').classList.remove('show'); var m = G.meta;
    if (m.mode === 'story') {
      if (m.n >= CH[m.ch].levels) {
        var ch = CH[m.ch];
        playStory(ch.outro, ch.art, function () {
          G.run = false; navStack = ['menu'];
          if (m.ch + 1 < CH.length) { selCh = m.ch + 1; renderLevels(); show('levels', true); toast('🔓 فصل بعدی باز شد!'); }
          else { show('menu', true); }
        });
      } else startStoryLevel(m.ch, m.n + 1);
    } else if (m.mode === 'endless') startEndless();
    else exitGame();
  };
  $('#r-retry').onclick = function () { $('#result').classList.remove('show'); restart(); };
  $('#r-menu').onclick = function () { $('#result').classList.remove('show'); exitGame(); };

  function restart() { setupLevel(G.meta); }
  function exitGame() { G.run = false; $('#pause').classList.remove('show'); show('menu', true); navStack = []; if (G.meta && G.meta.mode === 'story') { selCh = G.meta.ch; } }
  $('#h-pause').onclick = function () { G.paused = true; $('#pause').classList.add('show'); };
  $('#p-resume').onclick = function () { G.paused = false; $('#pause').classList.remove('show'); };
  $('#p-retry').onclick = function () { $('#pause').classList.remove('show'); restart(); };
  $('#p-exit').onclick = function () { exitGame(); };
  $('#h-hint').onclick = function () {
    if (!G.run || G.done || G.paused) return;
    if (save.coins < 8) return toast('برای راهنما ۸ سکه لازمه 🪙');
    save.coins -= 8; persist();
    var p = G.p, from = p.dir && p.to >= 0 ? p.to : p.i, b = E.bfs(G.L, from);
    G.hint = E.pathTo(b.par, G.L.exit); G.hintT = 4; Snd.key(); refreshCoins();
  };

  /* ---------- شروع مراحل ---------- */
  function zoneOf(ch, n) { return ch.zones.filter(function (z) { return n >= z.from && n <= z.to; })[0]; }
  function startStoryLevel(c, n) {
    if (n > save.prog[c] + 1) return;
    var ch = CH[c], z = zoneOf(ch, n), packs = [];
    if (n === 1 && !save.seen['i' + c]) packs.push({ key: 'i' + c, lines: ch.intro, art: ch.art });
    if (n === z.from && !save.seen['z' + c + '-' + z.from]) packs.push({ key: 'z' + c + '-' + z.from, lines: z.story, art: z.emoji + ' ' + z.emoji + ' ' + z.emoji });
    var cfg = E.levelConfig(ch, c, n);
    var meta = { mode: 'story', ch: c, n: n, cfg: cfg, pal: z.pal, boss: cfg.boss, label: (cfg.boss ? '👑 ' : '') + z.name + ' · ' + fa(n), tip: n === z.from ? z.tip : '' };
    playPacks(packs, function () { setupLevel(meta); });
  }
  function todayStr() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
  function startDaily() {
    var ds = todayStr(), cfg = E.dailyConfig(ds, ALL_PALS), best = (save.daily[ds] || {}).best;
    setupLevel({ mode: 'daily', date: ds, cfg: cfg, pal: cfg.pal, boss: false, label: '📅 چالش روزانه' + (best ? ' · رکورد ' + fa(best) + ' ث' : ''), tip: 'هر روز یک ماز تازه! جایزه‌ی اولین بار: ۲۰ سکه' });
  }
  function startEndless() {
    var n = save.endless, cfg = E.endlessConfig(n, ALL_PALS);
    setupLevel({ mode: 'endless', n: n, cfg: cfg, pal: cfg.pal, boss: cfg.boss, label: '♾️ بی‌نهایت · ' + fa(n), tip: '' });
  }

  /* ---------- منو ---------- */
  $('#b-continue').onclick = function () { Snd.unlock(); Snd.tap(); var r = nextLevelRef(); selCh = r.ch; startStoryLevel(r.ch, r.n); };
  $('#b-levels').onclick = function () { Snd.unlock(); Snd.tap(); selCh = nextLevelRef().ch; renderLevels(); show('levels'); };
  $('#b-daily').onclick = function () { Snd.unlock(); Snd.tap(); startDaily(); };
  $('#b-endless').onclick = function () { Snd.unlock(); Snd.tap(); startEndless(); };
  $('#b-shop').onclick = function () { Snd.unlock(); Snd.tap(); renderShop(); show('shop'); };
  $('#b-settings').onclick = function () { Snd.unlock(); Snd.tap(); renderSettings(); show('settings'); };

  /* ---------- ورودی ---------- */
  var tx = 0, ty = 0, down = false;
  stage.addEventListener('pointerdown', function (e) { down = true; tx = e.clientX; ty = e.clientY; Snd.unlock(); try { stage.setPointerCapture(e.pointerId); } catch (x) {} });
  stage.addEventListener('pointermove', function (e) {
    if (!down) return;
    var dx = e.clientX - tx, dy = e.clientY - ty;
    if (Math.hypot(dx, dy) > 20) { swipe(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? E.E : E.W) : (dy > 0 ? E.S : E.N)); tx = e.clientX; ty = e.clientY; }
  });
  stage.addEventListener('pointerup', function () { down = false; });
  stage.addEventListener('pointercancel', function () { down = false; });
  window.addEventListener('keydown', function (e) {
    var m = { ArrowUp: E.N, ArrowRight: E.E, ArrowDown: E.S, ArrowLeft: E.W, w: E.N, d: E.E, s: E.S, a: E.W };
    if (m[e.key]) { e.preventDefault(); swipe(m[e.key]); }
  });

  /* ---------- رندر ---------- */
  function clampCam(snap) {
    var L = G.L, ww = L.cols * G.cs, wh = L.rows * G.cs, pp = playerPos();
    var tx2 = ww <= cw ? -(cw - ww) / 2 : Math.max(0, Math.min(ww - cw, pp.x * G.cs - cw / 2));
    var ty2 = wh <= chh ? -(chh - wh) / 2 : Math.max(0, Math.min(wh - chh, pp.y * G.cs - chh / 2));
    if (snap) { G.camX = tx2; G.camY = ty2; } else { G.camX += (tx2 - G.camX) * 0.18; G.camY += (ty2 - G.camY) * 0.18; }
  }
  function hud() {
    var L = G.L, t = G.time;
    var el = $('#h-time');
    if (L.limit) { var left = Math.max(0, L.limit - t); el.textContent = '💧 ' + fa(Math.ceil(left)); el.classList.toggle('danger', left < 8); }
    else { el.textContent = fa(Math.floor(t / 60)) + ':' + fa(('0' + Math.floor(t % 60)).slice(-2)); el.classList.remove('danger'); }
    $('#h-coins').textContent = '🪙 ' + fa(G.got.size) + '/' + fa(L.coins.length);
    var k = '';
    G.held.forEach(function (c) { k += '<span class="kdot" style="border-color:' + KEY_COLORS[c] + '">🔑</span>'; });
    $('#h-keys').innerHTML = k;
  }
  function emoji(c, ch, x, y, size) { c.font = size + 'px "Apple Color Emoji","Noto Color Emoji",sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(ch, x, y); }
  function glow(c, x, y, r, col, a) {
    var g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.globalAlpha = a; c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, 6.3); c.fill(); c.globalAlpha = 1;
  }
  function draw() {
    var L = G.L, cs = G.cs, t = G.t, pal = G.pal, c = cx;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = pal.bg; c.fillRect(0, 0, cw, chh);
    var sx = G.shake > 0 ? (Math.random() - 0.5) * 8 * G.shake : 0, sy = G.shake > 0 ? (Math.random() - 0.5) * 8 * G.shake : 0;
    c.save(); c.translate(Math.round(-G.camX + sx), Math.round(-G.camY + sy));
    c.drawImage(G.stat, 0, 0, L.cols * cs, L.rows * cs);

    // ورودی و خروجی
    var s0 = cellXY(L.start), ex = cellXY(L.exit);
    glow(c, s0.x * cs, s0.y * cs, cs * 0.8, pal.wall, 0.35);
    glow(c, ex.x * cs, ex.y * cs, cs * (1 + 0.15 * Math.sin(t * 3)), '#ffe27a', 0.8);
    emoji(c, '🚪', ex.x * cs, ex.y * cs, cs * 0.7);

    // مسیر راهنما
    if (G.hint && G.hintT > 0) {
      c.strokeStyle = '#ffe27a'; c.lineWidth = cs * 0.12; c.setLineDash([cs * 0.18, cs * 0.2]); c.lineCap = 'round';
      c.globalAlpha = Math.min(1, G.hintT); c.beginPath();
      G.hint.forEach(function (i, k) { var q = cellXY(i); if (k) c.lineTo(q.x * cs, q.y * cs); else c.moveTo(q.x * cs, q.y * cs); });
      c.stroke(); c.setLineDash([]); c.globalAlpha = 1;
    }
    // درگاه‌ها
    L.portals.forEach(function (pp, k) {
      pp.forEach(function (cell) {
        var q = cellXY(cell), col = PORTAL_COLORS[k % 2];
        glow(c, q.x * cs, q.y * cs, cs * 0.6, col, 0.6);
        c.strokeStyle = col; c.lineWidth = 3;
        for (var j = 0; j < 2; j++) { c.beginPath(); c.arc(q.x * cs, q.y * cs, cs * (0.2 + j * 0.12), t * 3 + j * 2, t * 3 + j * 2 + 4); c.stroke(); }
      });
    });
    // درها
    G.doorAt.forEach(function (col, cell) {
      if (G.opened.has(cell)) return;
      var q = cellXY(cell), w = cs * 0.74;
      c.fillStyle = KEY_COLORS[col]; c.globalAlpha = 0.85;
      c.beginPath(); c.roundRect ? c.roundRect(q.x * cs - w / 2, q.y * cs - w / 2, w, w, cs * 0.14) : c.rect(q.x * cs - w / 2, q.y * cs - w / 2, w, w); c.fill(); c.globalAlpha = 1;
      emoji(c, '🔒', q.x * cs, q.y * cs, cs * 0.42);
    });
    // کلیدها
    G.keyAt.forEach(function (col, cell) {
      var q = cellXY(cell);
      glow(c, q.x * cs, q.y * cs, cs * 0.5, KEY_COLORS[col], 0.9);
      emoji(c, '🔑', q.x * cs, q.y * cs + Math.sin(t * 4) * 2, cs * 0.45);
    });
    // سکه‌ها
    L.coins.forEach(function (cell, i) {
      if (G.got.has(cell)) return;
      var q = cellXY(cell), r = cs * 0.17 * (1 + 0.12 * Math.sin(t * 5 + i));
      glow(c, q.x * cs, q.y * cs, cs * 0.4, '#ffd84d', 0.5);
      c.fillStyle = '#f5c542'; c.strokeStyle = '#fff2b0'; c.lineWidth = 2;
      c.beginPath(); c.arc(q.x * cs, q.y * cs, r, 0, 6.3); c.fill(); c.stroke();
    });
    // رد پا
    var sk = skinOf();
    G.trail.forEach(function (p, i) {
      c.globalAlpha = (i / G.trail.length) * 0.35; c.fillStyle = sk.trail;
      c.beginPath(); c.arc(p.x * cs, p.y * cs, cs * 0.1, 0, 6.3); c.fill();
    });
    c.globalAlpha = 1;
    // نگهبان‌ها
    L.guards.forEach(function (g) {
      var q = guardPos(g, t);
      glow(c, q.x * cs, q.y * cs, cs * 0.7, '#ff3b3b', 0.35);
      emoji(c, '💂', q.x * cs, q.y * cs + Math.sin(t * 8) * 1.5, cs * 0.62);
    });
    // دزد
    var pp2 = playerPos(), blink = G.inv > 0 && Math.floor(G.inv * 10) % 2 === 0;
    if (!blink) drawThief(c, pp2.x * cs, pp2.y * cs, cs * 0.27, sk, Math.sin(t * 9) * (G.p.dir ? 1.5 : 0.6));
    c.restore();

    // مه / تاریکی
    if (L.cfg.fog) {
      var px = pp2.x * cs - G.camX, py = pp2.y * cs - G.camY, flick = 1 + Math.sin(t * 7) * 0.02;
      var g = c.createRadialGradient(px, py, cs * 0.7, px, py, cs * 3.4 * flick);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.97)');
      c.fillStyle = g; c.fillRect(0, 0, cw, chh);
    }
    // آب
    if (L.limit) {
      var f = Math.min(1, G.time / L.limit), h = chh * f * 0.9;
      c.fillStyle = 'rgba(40,140,230,' + (0.22 + f * 0.25) + ')';
      c.beginPath(); c.moveTo(0, chh);
      for (var x = 0; x <= cw; x += 12) c.lineTo(x, chh - h + Math.sin(x * 0.03 + t * 3) * 5);
      c.lineTo(cw, chh); c.closePath(); c.fill();
    }
    if (G.flash > 0) { c.fillStyle = 'rgba(255,255,255,' + G.flash * 0.35 + ')'; c.fillRect(0, 0, cw, chh); }
  }

  var last = 0;
  function frame(ts) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.05, (ts - last) / 1000 || 0); last = ts;
    if (!G.run || !G.L || !$('#game').classList.contains('active')) return;
    if (!G.paused) {
      G.t += dt;
      if (!G.done) {
        G.time += dt; if (G.inv > 0) G.inv -= dt;
        stepPlayer(dt);
        if (G.inv <= 0 && !G.done) {
          var pp = playerPos();
          for (var i = 0; i < G.L.guards.length; i++) { var gp = guardPos(G.L.guards[i], G.t); if (Math.hypot(gp.x - pp.x, gp.y - pp.y) < 0.55) { caught(); break; } }
        }
        if (G.L.limit && G.time >= G.L.limit && !G.done) drown();
      }
      G.trailT += dt;
      if (G.trailT > 0.04) { G.trailT = 0; if (G.p.dir) { G.trail.push(playerPos()); if (G.trail.length > 14) G.trail.shift(); } else if (G.trail.length) G.trail.shift(); }
      if (G.flash > 0) G.flash -= dt * 2; if (G.shake > 0) G.shake -= dt; if (G.hintT > 0) G.hintT -= dt;
      clampCam(false); hud();
    }
    draw();
  }
  requestAnimationFrame(frame);
  refreshCoins();
})();
