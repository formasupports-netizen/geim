# دزد سایه‌ها 🥷

## ساخت APK از روی گوشی (بدون Android Studio)

### راه ۱ — فقط با مرورگر گوشی
1. در github.com یک repository جدید بسازید (مثلاً shadow-thief).
2. Add file ← Upload files، و این فایل‌ها را انتخاب کنید (همه کنار هم، بدون پوشه):
   index.html, style.css, chapters.js, engine.js, game.js, package.json, capacitor.config.json, .gitignore
3. Commit کنید.
4. Add file ← Create new file. در کادر اسم دقیقاً این را بنویسید:
   .github/workflows/build.yml
   و محتوای فایل build-apk.yml.txt را داخلش paste کنید. Commit کنید.
5. تب Actions ← «Build Android APK» ← صبر کنید ۵ تا ۸ دقیقه (تیک سبز).
6. داخل همان اجرا، پایین صفحه در بخش Artifacts فایل shadow-thief-apk را دانلود کنید.
   (zip است؛ باز کنید و app-debug.apk را نصب کنید. «نصب از منبع ناشناس» را اجازه دهید.)

### راه ۲ — با Termux
pkg install git unzip
termux-setup-storage
unzip ~/storage/downloads/shadow-thief.zip && cd shadow-thief
git init && git add . && git commit -m "first"
git branch -M main
git remote add origin https://github.com/USERNAME/shadow-thief.git
git push -u origin main     # رمز = Personal Access Token

## اضافه‌کردن فصل جدید
در فایل chapters.js یک آبجکت جدید به آخر آرایه‌ی CHAPTERS اضافه کنید
(title, intro, outro, zones). بقیه‌ی کار خودکار است.

## تست در مرورگر
فایل index.html را در مرورگر باز کنید. کلیدهای جهت‌نما هم کار می‌کنند.
