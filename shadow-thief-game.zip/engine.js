/* موتور تولید ماز و مرحله (بدون وابستگی به صفحه، قابل تست در Node) */
(function (root) {
  'use strict';
  var N = 1, E = 2, S = 4, W = 8;
  var DIRS = [N, E, S, W];
  var DR = { 1: -1, 2: 0, 4: 1, 8: 0 };
  var DC = { 1: 0, 2: 1, 4: 0, 8: -1 };
  var OPP = { 1: 4, 2: 8, 4: 1, 8: 2 };

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function hashStr(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function popcount(x) { return (x & 1) + ((x >> 1) & 1) + ((x >> 2) & 1) + ((x >> 3) & 1); }
  function shuffle(a, rnd) {
    for (var i = a.length - 1; i > 0; i--) { var j = (rnd() * (i + 1)) | 0; var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  }

  function genMaze(cols, rows, rnd, braid) {
    var m = new Uint8Array(cols * rows), seen = new Uint8Array(cols * rows);
    var s0 = Math.floor(rnd() * cols * rows), stack = [s0];
    seen[s0] = 1;
    while (stack.length) {
      var cur = stack[stack.length - 1], r = (cur / cols) | 0, c = cur % cols, opts = [];
      for (var k = 0; k < 4; k++) {
        var d = DIRS[k], nr = r + DR[d], nc = c + DC[d];
        if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && !seen[nr * cols + nc]) opts.push(d);
      }
      if (!opts.length) { stack.pop(); continue; }
      var dd = opts[(rnd() * opts.length) | 0], ni = (r + DR[dd]) * cols + c + DC[dd];
      m[cur] |= dd; m[ni] |= OPP[dd]; seen[ni] = 1; stack.push(ni);
    }
    for (var i = 0; i < m.length; i++) {
      if (popcount(m[i]) === 1 && rnd() < braid) {
        var rr = (i / cols) | 0, cc = i % cols, cand = [];
        for (var q = 0; q < 4; q++) {
          var d2 = DIRS[q];
          if (m[i] & d2) continue;
          var r2 = rr + DR[d2], c2 = cc + DC[d2];
          if (r2 >= 0 && r2 < rows && c2 >= 0 && c2 < cols) cand.push(d2);
        }
        if (cand.length) {
          var pick = cand[(rnd() * cand.length) | 0];
          m[i] |= pick; m[(rr + DR[pick]) * cols + cc + DC[pick]] |= OPP[pick];
        }
      }
    }
    return m;
  }

  function nbrs(L, i) {
    var out = [], r = (i / L.cols) | 0, c = i % L.cols;
    for (var k = 0; k < 4; k++) {
      var d = DIRS[k];
      if (L.m[i] & d) out.push([(r + DR[d]) * L.cols + c + DC[d], d]);
    }
    return out;
  }
  function bfs(L, src, blocked) {
    var n = L.m.length, dist = new Int16Array(n).fill(-1), par = new Int32Array(n).fill(-1), q = [src];
    dist[src] = 0;
    for (var h = 0; h < q.length; h++) {
      var u = q[h], nb = nbrs(L, u);
      for (var j = 0; j < nb.length; j++) {
        var v = nb[j][0];
        if (dist[v] < 0 && !(blocked && blocked.has(v))) { dist[v] = dist[u] + 1; par[v] = u; q.push(v); }
      }
    }
    return { dist: dist, par: par };
  }
  function pathTo(par, t) {
    var p = [];
    for (var v = t; v !== -1; v = par[v]) p.push(v);
    return p.reverse();
  }
  function randomWalk(L, start, len, rnd) {
    var seg = [start], seen = new Set(seg);
    while (seg.length < len) {
      var cur = seg[seg.length - 1], opts = nbrs(L, cur).map(function (x) { return x[0]; }).filter(function (v) { return !seen.has(v); });
      if (!opts.length) break;
      var v = opts[(rnd() * opts.length) | 0];
      seg.push(v); seen.add(v);
    }
    return seg;
  }
  // نگهبان باید یک انشعاب فرعی داشته باشد تا بازیکن بتواند جاخالی بدهد
  function hasPocket(L, seg) {
    var set = new Set(seg);
    for (var i = 1; i < seg.length - 1; i++) {
      var nb = nbrs(L, seg[i]);
      for (var j = 0; j < nb.length; j++) if (!set.has(nb[j][0])) return true;
    }
    return false;
  }

  function buildLevel(cfg) {
    var rnd = mulberry32(cfg.seed), cols = cfg.cols, rows = cfg.rows;
    var L = { cfg: cfg, cols: cols, rows: rows };
    L.m = genMaze(cols, rows, rnd, cfg.braid);
    var n = L.m.length, i, k;
    L.start = Math.floor(rnd() * cols);
    var b = bfs(L, L.start), exit = L.start, best = -1;
    for (i = 0; i < n; i++) if (b.dist[i] > best) { best = b.dist[i]; exit = i; }
    L.exit = exit;
    var path = pathTo(b.par, exit);
    L.path = path; L.pathLen = path.length - 1;
    var used = new Set([L.start, exit]);

    // درها
    var doorCells = [], K = Math.min(cfg.keys, 4);
    for (k = 0; k < K; k++) {
      var target = Math.floor(path.length * (k + 1) / (K + 1)), placed = -1;
      for (var off = 0; off < path.length && placed < 0; off++) {
        var tries = [target + off, target - off];
        for (var ti = 0; ti < 2; ti++) {
          var idx = tries[ti];
          if (idx < 2 || idx >= path.length - 1) continue;
          var cell = path[idx];
          if (used.has(cell)) continue;
          var blk = new Set(doorCells.concat([cell]));
          if (bfs(L, L.start, blk).dist[exit] < 0) { placed = cell; break; }
        }
      }
      if (placed >= 0) { doorCells.push(placed); used.add(placed); }
    }
    doorCells.sort(function (a, c) { return path.indexOf(a) - path.indexOf(c); });

    // کلیدها (هر کلید در بخشی قرار می‌گیرد که قبل از همان در قابل دسترسی است)
    L.doors = []; L.keys = [];
    for (k = 0; k < doorCells.length; k++) {
      var rr = bfs(L, L.start, new Set(doorCells.slice(k))), maxd = 0;
      for (i = 0; i < n; i++) if (rr.dist[i] > maxd) maxd = rr.dist[i];
      var cand = [], any = [];
      for (i = 0; i < n; i++) {
        if (rr.dist[i] < 1 || used.has(i)) continue;
        any.push(i);
        if (rr.dist[i] >= Math.max(3, maxd * 0.5)) cand.push(i);
      }
      var de = cand.filter(function (x) { return popcount(L.m[x]) === 1; });
      var pool = de.length ? de : (cand.length ? cand : any);
      if (!pool.length) continue;
      var kc = pool[(rnd() * pool.length) | 0];
      used.add(kc);
      L.keys.push({ cell: kc, color: k });
      L.doors.push({ cell: doorCells[k], color: k });
    }

    // درگاه‌ها
    L.portals = [];
    if (cfg.portals > 0) {
      var reg = bfs(L, L.start, new Set(doorCells)), pp = [];
      for (i = 0; i < n; i++) if (reg.dist[i] >= 3 && !used.has(i)) pp.push(i);
      shuffle(pp, rnd);
      for (var p = 0; p < Math.min(cfg.portals, 2); p++) {
        var a = pp.pop();
        if (a === undefined) break;
        var ar = (a / cols) | 0, ac = a % cols, bi = -1;
        for (var q = pp.length - 1; q >= 0; q--) {
          var qq = pp[q], dd = Math.abs(((qq / cols) | 0) - ar) + Math.abs((qq % cols) - ac);
          if (dd >= (cols + rows) / 2) { bi = q; break; }
        }
        if (bi < 0) bi = pp.length - 1;
        if (bi < 0) break;
        var b2 = pp.splice(bi, 1)[0];
        L.portals.push([a, b2]); used.add(a); used.add(b2);
      }
    }

    // سکه‌ها (اول بن‌بست‌ها)
    var dead = [], others = [];
    for (i = 0; i < n; i++) { if (used.has(i)) continue; (popcount(L.m[i]) === 1 ? dead : others).push(i); }
    shuffle(dead, rnd); shuffle(others, rnd);
    var cpool = dead.concat(others);
    L.coins = [];
    for (i = 0; i < cfg.coins && i < cpool.length; i++) { L.coins.push(cpool[i]); used.add(cpool[i]); }

    // نگهبان‌ها
    L.guards = [];
    var gTries = 0;
    while (L.guards.length < cfg.guards && gTries < 120) {
      gTries++;
      var len = 5 + ((rnd() * 6) | 0), seg;
      if (rnd() < 0.7 && path.length > len + 8) {
        var s = 3 + ((rnd() * (path.length - len - 6)) | 0);
        seg = path.slice(s, s + len);
      } else seg = randomWalk(L, (rnd() * n) | 0, len, rnd);
      if (seg.length < 5 || !hasPocket(L, seg)) continue;
      var bad = false;
      for (i = 0; i < seg.length; i++) if (seg[i] === exit || b.dist[seg[i]] < 5) { bad = true; break; }
      if (bad) continue;
      L.guards.push({ seg: seg, speed: cfg.gspeed * (0.85 + rnd() * 0.3), phase: rnd() * 2 * (seg.length - 1) });
    }

    L.par = L.pathLen * 0.35 + 8 + L.keys.length * 4;
    L.limit = cfg.water ? Math.ceil(L.pathLen * 0.55 + 12) : 0;
    return L;
  }

  function makeConfig(o) {
    var d = o.d, boss = !!o.boss;
    var cols = Math.min(6 + Math.floor(d / 9), 24), rows = Math.min(8 + Math.floor(d / 6), 38);
    if (boss) { cols = Math.min(cols + 3, 26); rows = Math.min(rows + 4, 42); }
    return {
      seed: o.seed, d: d, boss: boss, cols: cols, rows: rows,
      keys: o.keys | 0, guards: o.guards | 0, portals: o.portals | 0,
      fog: !!o.fog, water: !!o.water,
      coins: Math.min(3 + Math.floor(d / 12), 12),
      braid: o.keys ? 0.02 : 0.08,
      gspeed: Math.min(1.5 + d * 0.009, 3.0)
    };
  }

  function levelConfig(ch, chIdx, n) {
    var z = null;
    for (var i = 0; i < ch.zones.length; i++) if (n >= ch.zones[i].from && n <= ch.zones[i].to) z = ch.zones[i];
    var t = (n - z.from) / Math.max(1, z.to - z.from), f = z.f || {};
    function lerp(r) { return r ? Math.round(r[0] + (r[1] - r[0]) * t) : 0; }
    var boss = n % 20 === 0;
    var cfg = makeConfig({
      seed: hashStr('thief-' + chIdx + '-' + n), d: chIdx * 100 + n - 1, boss: boss,
      keys: lerp(f.keys) + (boss && f.keys ? 1 : 0),
      guards: lerp(f.guards) + (boss && f.guards ? 1 : 0),
      portals: lerp(f.portals), fog: f.fog, water: f.water
    });
    cfg.zone = z;
    return cfg;
  }

  function endlessConfig(n, pals) {
    var d = Math.min(20 + n * 3, 220);
    var cfg = makeConfig({
      seed: hashStr('endless-' + n), d: d, boss: n % 10 === 0,
      keys: n % 3, guards: d > 40 ? 1 + (n % 4) : 0, portals: n % 4 === 3 ? 1 : 0,
      fog: n % 5 === 4, water: n % 6 === 5
    });
    cfg.pal = pals[n % pals.length];
    return cfg;
  }

  function dailyConfig(dateStr, pals) {
    var rnd = mulberry32(hashStr('daily-' + dateStr));
    var cfg = makeConfig({
      seed: hashStr('daily-' + dateStr), d: 30 + ((rnd() * 70) | 0), boss: false,
      keys: (rnd() * 3) | 0, guards: 1 + ((rnd() * 3) | 0), portals: (rnd() * 2) | 0,
      fog: rnd() < 0.3, water: rnd() < 0.2
    });
    cfg.pal = pals[(rnd() * pals.length) | 0];
    return cfg;
  }

  root.Engine = {
    N: N, E: E, S: S, W: W, DIRS: DIRS, DR: DR, DC: DC, OPP: OPP,
    mulberry32: mulberry32, hashStr: hashStr, popcount: popcount,
    buildLevel: buildLevel, levelConfig: levelConfig, endlessConfig: endlessConfig, dailyConfig: dailyConfig,
    bfs: bfs, pathTo: pathTo, nbrs: nbrs
  };
  if (typeof module !== 'undefined') module.exports = root.Engine;
})(typeof window !== 'undefined' ? window : globalThis);
